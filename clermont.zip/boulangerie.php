<?php
include('entete.php');
?>
<!doctype html>
<html lang="fr">
    <br><br><br><br>
    <body style="background-color:#E5E5E5;">
        <center>
            <h1>Site de la mairie de Clermont-Ferrand</h1>
            <h2>Les Boulangeries de Clermont-Ferrand<h2>
        <table>
            <tr>
                <td>
                    <div class="card" style="width: 20rem;">
                        <img src="https://www.pagesjaunes.fr/media/agc/e2/ee/a9/00/00/8d/98/8c/38/ea/5d84e2eea900008d988c38ea/5d84e2eea900008d988c38eb.png" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Moulin de Païou</h5>
                            <p class="card-title">77 Rte de Charmeil, 63000 Clermont-Ferrand – 04 70 41 38 97</p>
                            <a href="boulangerie1.php" class="btn btn-primary stretched-link">Voir</a>
                        </div>
				    </div>
                </td>
                <td>
                    <div class="card" style="width: 20rem;">
                        <img src="https://lh3.googleusercontent.com/p/AF1QipOAfYZ-Q2RXpUushEsj7d3MSgOUpwqVzNmz3cLc=s1600-w640" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Boulangerie Moderne</h5>
                            <p class="card-title">18 Rue du Port, 63000 Clermont-Ferrand – 04 73 24 80 30</p>
                            <a href="boulangerie2.php" class="btn btn-primary stretched-link">Voir</a>
                        </div>
				    </div>
                </td>
                <td>
                    <div class="card" style="width: 24rem;">
                        <img src="https://lh5.googleusercontent.com/p/AF1QipP_Rm-J7pKqHrVakAQRplEg1n91YR0oc4oif40_=w500-h500-k-no" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">La Gourmandine</h5>
                            <p class="card-title">185 Bd Étienne Clémentel, 63100 Clermont-Ferrand – 04 73 23 15 00</p>
                            <a href="boulangerie3.php" class="btn btn-primary stretched-link">Voir</a>
                        </div>
				    </div>
                </td>
                <td>
                    <div class="card" style="width: 19rem;">
                        <img src="https://lh5.googleusercontent.com/p/AF1QipP93b3G3TBkCA0FzorFtJAyfg-eOuQE1O_cvT2T=w500-h500-k-no" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Restaurant Le 62, terrasse ombragée</h5>
                            <p class="card-title">6-8 Bd Robert Schuman, 63000 Clermont-Ferrand – 04 73 44 93 15</p>
                            <a href="boulangerie4.php" class="btn btn-primary stretched-link">Voir</a>
                        </div>
				    </div>
                </td>
            </tr>
        </table>
        </center>
    </body>
</html>