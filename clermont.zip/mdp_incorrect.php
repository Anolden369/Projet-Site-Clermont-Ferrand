<?php
include('entete.php');
?>
<!doctype html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
    </head>
    <br><br><br><br>
    <body style="background-color:#E5E5E5;">
        <center>
            <br><br><br>
            <h1>Le mot de passe est incorrect !</h1>
            <h2>Reconnectez-vous en haut à droite de la page !<h2>
            <br>
        </center>
    </body>
</html>