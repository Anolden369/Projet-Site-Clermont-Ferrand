<!doctype html>
<?php
include('entete.php')
?>
<html lang="fr">
    <br><br><br><br>
    <body style="background-color:#E5E5E5;">
            <center>
                <h2>Nos differentes coiffures <h2>
        <table>
            <tr>
                <td>
                    <div class="card" style="width: 15rem;">
                    <img src="https://i.pinimg.com/originals/c1/2b/33/c12b3377e3415b73ff629359ac87e146.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">affro Femme</h5>
                        <p class="card-text">40€</p>
                        <a href="#" class="btn btn-primary stretched-link">Réserver</a>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 15rem;">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSdRCq-8edK7NZoVZeXWUIbxV10Po2m0T-U_A&usqp=CAU" class="card-img-top" alt="">
                    <div class="card-body">
                    <h5 class="card-title">Carré Femme</h5>
                        <p class="card-text">35€</p>
                        <a href="#" class="btn btn-primary stretched-link">Réserver</a>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 15rem;">
                    <img src="https://www.astuces-pratiques.fr/imagesarticles/7274/comment-reparer-les-pointes-abimees-de-vos-cheveux.png" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Pointes</h5>
                        <p class="card-text">15€</p>
                        <a href="#" class="btn btn-primary stretched-link">Réserver</a>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 15rem;">
                    <img src="https://www.barbededarwin.fr/wp-content/uploads/2021/06/degrade-bas-e1624815998209.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Degradés Homme</h5>
                        <p class="card-text">15€</p>
                        <a href="#" class="btn btn-primary stretched-link">Réserver</a>
                    </div>
                    </div>
                </td>
            <tr>
            </tr>
                <td>
                    <div class="card" style="width: 13rem;">
                    <img src="https://macouleurdecheveux.fr/wp-content/uploads/2016/05/Coloration-blonde-tie-and-dye-229x300.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">colorations Femme</h5>
                        <p class="card-text">60-90€</p>
                        <a href="#" class="btn btn-primary stretched-link">Réserver</a>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 15rem;">
                    <img src="http://coupedecheveuxhomme.org/wp-content/uploads/2018/06/20398680_1614277701925160_8008250772917583872_n1-1024x10241.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Colorations Homme</h5>
                        <p class="card-text">35-50€</p>
                        <a href="#" class="btn btn-primary stretched-link">Réserver</a>
                    </div>
                    </div>
                </td>
            </tr>
        </table>
    </body>
</html>