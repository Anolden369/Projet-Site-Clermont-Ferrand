<?php
include('entete.php');
?>
<!doctype html>
<html lang="fr">
    <br><br><br><br>
    <body style="background-color:#E5E5E5;">
        <center>
            <h1>Site de la mairie de Clermont-Ferrand</h1>
            <h2>Les Coiffeurs de Clermont-Ferrand<h2>
        <table>
            <tr>
                <td>
                    <div class="card" style="width: 20rem;">
                        <img src="https://shinecoiffeur.com/images/pontduchateau.jpg" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Shine Coiffeurs Créateurs</h5>
                            <p class="card-title">Centre Jaude, 63000 Clermont-Ferrand – 04 73 34 33 04</p>
                            <a href="coiffeur1.php" class="btn btn-primary stretched-link">Voir</a>
                        </div>
				    </div>
                </td>
                <td>
                    <div class="card" style="width: 20rem;">
                        <img src="https://res.cloudinary.com/planity/image/upload/t_d_main,f_auto/bohzvink23dx9k3yziy8" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Marco Donelli </h5>
                            <p class="card-title">14 Rue Gonod, 63000 Clermont-Ferrand – 04 73 35 53 59</p>
                            <a href="coiffeur1.php" class="btn btn-primary stretched-link">Voir</a>
                        </div>
				    </div>
                </td>
                <td>
                    <div class="card" style="width: 24rem;">
                        <img src="https://www.pagesjaunes.fr/media/ugc/jean_louis_david_07505600_100846518" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Jean Louis David</h5>
                            <p class="card-title">Rue Georges Clemenceau, 63000 Clermont-Ferrand – 04 73 91 54 46</p>
                            <a href="coiffeur1.php" class="btn btn-primary stretched-link">Voir</a>
                        </div>
				    </div>
                </td>
                <td>
                    <div class="card" style="width: 19rem;">
                        <img src="https://www.pagesjaunes.fr/media/ugc/magny_sun_07726800_113151680?w=400&h=300" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">HAIR'M Coiffure</h5>
                            <p class="card-title">15 Rue Saint-Hérem, 63000 Clermont-Ferrand – 04 73 35 54 01</p>
                            <a href="coiffeur1.php" class="btn btn-primary stretched-link">Voir</a>
                        </div>
				    </div>
                </td>
            </tr>
        </table>
        </center>
    </body>
</html>