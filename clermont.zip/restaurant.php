<?php
include('entete.php');
?>
<!doctype html>
<html lang="fr">
    <br><br><br><br>
    <body style="background-color:#E5E5E5;">
        <center>
            <h1>Site de la mairie de Clermont-Ferrand</h1>
            <h2>Les Restaurants de Clermont-Ferrand<h2>
        <table>
            <tr>
                <td>
                    <div class="card" style="width: 20rem;">
                        <img src="https://www.radiofrance.fr/s3/cruiser-production/2021/06/a0decf6e-aa1d-408b-8a1d-11c21e8301f1/860_img_20210609_144710_resized_20210609_031138761.jpg" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Restaurant Etoilé L'Ostal</h5>
                            <p class="card-title">16 Rue Claussmann, 63000 Clermont-Ferrand – 04 73 27 77 86</p>
                            <a href="restaurant1.php" class="btn btn-primary stretched-link">Voir</a>
                        </div>
				    </div>
                </td>
                <td>
                    <div class="card" style="width: 20rem;">
                        <img src="https://media-cdn.tripadvisor.com/media/photo-s/12/fc/65/e7/le-bistrot-d-a-cote-pile.jpg" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Le Bistrot d'à Côté</h5>
                            <p class="card-title">16 Rue des Minimes, 63000 Clermont-Ferrand – 04 73 29 16 16</p>
                            <a href="restaurant1.php" class="btn btn-primary stretched-link">Voir</a>
                        </div>
				    </div>
                </td>
                <td>
                    <div class="card" style="width: 20rem;">
                        <img src="https://www.gourmandine-restaurant.com/wp-content/uploads/2016/04/gourmandine_salle_4.jpg" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">La Gourmandine</h5>
                            <p class="card-title">8 Rue des Minimes, 63000 Clermont-Ferrand – 04 73 28 27 82</p>
                            <a href="restaurant1.php" class="btn btn-primary stretched-link">Voir</a>
                        </div>
				    </div>
                </td>
                <td>
                    <div class="card" style="width: 20rem;">
                        <img src="https://res.cloudinary.com/tf-lab/image/upload/restaurant/671c4633-9c94-424c-913b-ffcf3c5b3b9f/c4e75833-ba34-4a4a-99c0-0b27b04dd96f.jpg" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Restaurant Le 62, terrasse ombragée</h5>
                            <p class="card-title">62 Rue Fontgieve, 63000 Clermont-Ferrand – 04 73 36 18 49</p>
                            <a href="restaurant1.php" class="btn btn-primary stretched-link">Voir</a>
                        </div>
				    </div>
                </td>
            </tr>
        </table>
        </center>
    </body>
</html>