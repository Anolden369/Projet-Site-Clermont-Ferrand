<!doctype html>
<?php
include('entete.php')
?>
<html lang="fr">
    <br><br><br><br>
    <body style="background-color:#E5E5E5;">
            <center>
                <h1>MOULIN DE PAÏOU - BOULANGERIE PÂTISSERIE ARTISANALE</h1>
                <h2>Notre gamme <h2>
        <table>
            <tr>
                <td>
                    <div class="card" style="width: 15rem;">
                    <img src="image/Le moulin de Païou.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Le moulin de Païou</h5>
                        <p class="card-text">1€</p>
                        <a href="#" class="btn btn-primary stretched-link">Acheter</a>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 15rem;">
                    <img src="image/Le pain lardon.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                    <h5 class="card-title">Le pain lardon</h5>
                        <p class="card-text">1.50€</p>
                        <a href="#" class="btn btn-primary stretched-link">Acheter</a>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 15rem;">
                    <img src="image/Les cookies.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Les Cookies</h5>
                        <p class="card-text">2€</p>
                        <a href="#" class="btn btn-primary stretched-link">Acheter</a>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 15rem;">
                    <img src="image/Eclair vanille.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Eclair vanille</h5>
                        <p class="card-text">3.50€</p>
                        <a href="#" class="btn btn-primary stretched-link">Acheter</a>
                    </div>
                    </div>
                </td>
            <tr>
            </tr>
                <td>
                    <div class="card" style="width: 15rem;">
                    <img src="image/choux caramel.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Choux caramel</h5>
                        <p class="card-text">4€</p>
                        <a href="#" class="btn btn-primary stretched-link">Acheter</a>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 15rem;">
                    <img src="image/Sandwich.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Sandwich 3 en 1</h5>
                        <p class="card-text">5.50€</p>
                        <a href="#" class="btn btn-primary stretched-link">Acheter</a>
                    </div>
                    </div>
                </td>
            </tr>
        </table>
    </body>
</html>