<?php
include('entete.php');
?>
<!doctype html>
<html lang="fr">
    <br><br><br><br>
    <center>
    <body style="background-color:#E5E5E5;">
        <h1>Site de la mairie de Clermont-Ferrand</h1>
        <h2>L'histoire de la ville de Clermont-Ferrand<h2>
            <table>
                <tr>
                    <td>
                        <div class="card" style="width: 40rem;">
                            <img src="https://www.la-prepa-des-inp.fr/medias/photo/cathedrale-de-clermont-et-place-de-la-victoire-3344171_1623922106130-jpeg?ID_FICHE=677062" class="card-img-top" alt="">
                            <div class="card-body">
                                <h5 class="card-title">  La ville de Clermont-Ferrand est née de l'union de deux villes distinctes, Clermont et Montferrand, décidée par Louis XIII et confirmée sous Louis XV. Pendant longtemps, malgré les décisions officielles d'union, Clermont et Montferrand ont été des agglomérations séparées, de part et d'autre de l'actuelle avenue de la République, par un vide qui n'a été urbanisé qu'à une époque récente. Clermont et Montferrand furent, dans le passé, des villes très différentes.</h5>
                                <h5 class="card-title">Alors que Montferrand fut fondée au début du XIIe siècle par les comtes d'Auvergne sur le modèle des villes neuves du Midi, Clermont remonte à l'antiquité et prit rapidement le caractère d'une ville épiscopale. La plus ancienne mention de l'existence de Clermont figure dans l'œuvre de Strabon, au début du ler siècle. La ville est alors dénommée Nemossos et qualifiée de "métropole" des arvernes, ce qui démontre son importance. Au milieu du ler siècle, elle prit la dénomination d'Augustonemetum et connut une phase d'extension qui se termina au milieu du IIIe siècle.</h5>
                            </div>
                        </div>
                    </td>
                </tr>
            </table>
    </body>
    </center>
</html>