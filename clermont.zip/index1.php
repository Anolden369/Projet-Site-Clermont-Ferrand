<!doctype html>
<?php
include('entete.php')
?>
<html lang="fr">
<body style="background-color:#E5E5E5;">
	<br><br><br>
	<table>
		<tr>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/1f/3b/32/20069151/1540-1/tsp20221013132529/iPhone-14-Pro-6-1-5G-Double-SIM-128-Go-Violet-intense.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Violet</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/07/3b/32/20069127/1540-1/tsp20221020034617/iPhone-14-Pro-6-1-5G-Double-SIM-128-Go-Argent.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Blanc</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/00/32/32/20066816/3756-1/tsp20221020034617/iPhone-14-Pro-Max-6-7-5G-Double-SIM-128-Go-Noir-sideral.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Noir</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/1f/3b/32/20069151/1540-1/tsp20221013132529/iPhone-14-Pro-6-1-5G-Double-SIM-128-Go-Violet-intense.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Violet</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/07/3b/32/20069127/1540-1/tsp20221020034617/iPhone-14-Pro-6-1-5G-Double-SIM-128-Go-Argent.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Blanc</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/00/32/32/20066816/3756-1/tsp20221020034617/iPhone-14-Pro-Max-6-7-5G-Double-SIM-128-Go-Noir-sideral.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Noir</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
		</tr>
	</table>
	<table>
		<tr>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/1f/3b/32/20069151/1540-1/tsp20221013132529/iPhone-14-Pro-6-1-5G-Double-SIM-128-Go-Violet-intense.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Violet</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/07/3b/32/20069127/1540-1/tsp20221020034617/iPhone-14-Pro-6-1-5G-Double-SIM-128-Go-Argent.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Blanc</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/00/32/32/20066816/3756-1/tsp20221020034617/iPhone-14-Pro-Max-6-7-5G-Double-SIM-128-Go-Noir-sideral.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Noir</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/1f/3b/32/20069151/1540-1/tsp20221013132529/iPhone-14-Pro-6-1-5G-Double-SIM-128-Go-Violet-intense.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Violet</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/07/3b/32/20069127/1540-1/tsp20221020034617/iPhone-14-Pro-6-1-5G-Double-SIM-128-Go-Argent.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Blanc</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/00/32/32/20066816/3756-1/tsp20221020034617/iPhone-14-Pro-Max-6-7-5G-Double-SIM-128-Go-Noir-sideral.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Noir</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
		</tr>
	</table>
	<table>
		<tr>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/1f/3b/32/20069151/1540-1/tsp20221013132529/iPhone-14-Pro-6-1-5G-Double-SIM-128-Go-Violet-intense.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Violet</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/07/3b/32/20069127/1540-1/tsp20221020034617/iPhone-14-Pro-6-1-5G-Double-SIM-128-Go-Argent.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Blanc</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/00/32/32/20066816/3756-1/tsp20221020034617/iPhone-14-Pro-Max-6-7-5G-Double-SIM-128-Go-Noir-sideral.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Noir</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/1f/3b/32/20069151/1540-1/tsp20221013132529/iPhone-14-Pro-6-1-5G-Double-SIM-128-Go-Violet-intense.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Violet</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/07/3b/32/20069127/1540-1/tsp20221020034617/iPhone-14-Pro-6-1-5G-Double-SIM-128-Go-Argent.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Blanc</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
			<td>
				<div class="card" style="width: 20rem;">
				<img src="https://static.fnac-static.com/multimedia/Images/FR/MDM/00/32/32/20066816/3756-1/tsp20221020034617/iPhone-14-Pro-Max-6-7-5G-Double-SIM-128-Go-Noir-sideral.jpg" class="card-img-top" alt="">
				<div class="card-body">
					<h5 class="card-title">iPhone 14 Pro - Noir</h5>
					<p class="card-text">À partir de 1 329 €</p>
					<a href="#" class="btn btn-primary stretched-link">Acheter</a>
				</div>
				</div>
			</td>
		</tr>
	</table>
</body>
</html>