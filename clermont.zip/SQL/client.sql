-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Mer 01 Décembre 2021 à 07:26
-- Version du serveur :  5.7.11
-- Version de PHP :  5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projet`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `num` int(3) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(15) NOT NULL,
  `age` int(100) NOT NULL,
  `rue` varchar(100) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `cp` varchar(5) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `mdp` varchar(25) NOT NULL,
  `sexe` text NOT NULL,
  `ville` varchar(30) NOT NULL,
  `pseudo` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`num`, `nom`, `prenom`, `age`, `rue`, `tel`, `cp`, `mail`, `mdp`, `sexe`, `ville`, `pseudo`) VALUES
(1, 'Banchi', 'Haris', 55, 'fsdgsdf', '0688452365', '55555', 'root@dgd.fr', 'e', 'homme', 'les lilas', 'qsdqsd'),
(2, 'Banchi', 'Haris', 53, 'garage', '0688452365', '35358', 'root@hotmail.com', 'root', 'femme', 'puteaux', 'qsdqsd'),
(3, 'Banchi', 'ching chang', 99, 'fsdgsdf', '0688452365', '75041', 'root@hotmail.com', 'root', 'homme', 'les lilas', 'qsdqsd'),
(4, 'Banchi', 'ching chang', 99, 'fsdgsdf', '0688452365', '75041', 'root@hotmail.com', 'root', 'homme', 'les lilas', 'qsdqsd');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`num`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `num` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
