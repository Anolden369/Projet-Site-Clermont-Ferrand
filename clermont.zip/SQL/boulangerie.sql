-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mer. 06 jan. 2021 à 07:35
-- Version du serveur :  5.7.26
-- Version de PHP :  7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `boulangerie`
--

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `numero` int(100) NOT NULL AUTO_INCREMENT,
  `designation` varchar(30) NOT NULL,
  `description` varchar(300) NOT NULL,
  `image` varchar(20) NOT NULL,
  `famille` varchar(20) NOT NULL,
  `prix` decimal(3,2) NOT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `articles`
--

INSERT INTO `articles` (`numero`, `designation`, `description`, `image`, `famille`, `prix`) VALUES
(1, 'croissant', 'Nos croissants sont élaborés avec le plus grand soin. <br> Ils sont confectionnés dans notre atelier à partir de farine biologique et de beurre AOC.', 'croissant.jpg', 'viennoiserie', '1.00'),
(4, 'pain au chocolat', '', 'painchoco.png', 'viennoiserie', '1.20'),
(5, 'éclair au chocolat', '', 'eclairchoco.png', 'patisserie', '2.00'),
(6, 'baguette', '', 'baguette.jpg', 'boulangerie', '0.95'),
(7, 'pain aux céréales', '', 'paincer.jpg', 'boulangerie', '3.50'),
(8, 'religieuse', '', 'religieuse.jpg', 'patisserie', '2.50');

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `numero` int(100) NOT NULL AUTO_INCREMENT,
  `nom` text NOT NULL,
  `prenom` text NOT NULL,
  `rue` varchar(50) NOT NULL,
  `ville` varchar(50) NOT NULL,
  `cp` int(100) NOT NULL,
  `pseudo` varchar(50) NOT NULL,
  `mdp` varchar(100) NOT NULL,
  `tel` varchar(14) NOT NULL,
  `mail` varchar(50) NOT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`numero`, `nom`, `prenom`, `rue`, `ville`, `cp`, `pseudo`, `mdp`, `tel`, `mail`) VALUES
(3, 't', 'd', 's', 's', 99999, 'nico', '$2y$10$d20U45.exO4XgiizJlHX9eAIh4OjhenaGv2R7yvKC30STSX17Vl6i', '000000009', 'd@d.es');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
