-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Sam 05 Novembre 2022 à 21:03
-- Version du serveur :  5.6.20-log
-- Version de PHP :  5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `projetcf`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `numCat` int(2) NOT NULL,
  `nomCat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `categorie`
--

INSERT INTO `categorie` (`numCat`, `nomCat`) VALUES
(1, 'entrée'),
(2, 'plat'),
(3, 'boisson'),
(4, 'dessert');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
`num` int(3) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(15) NOT NULL,
  `pseudo` varchar(15) NOT NULL,
  `mdp` varchar(25) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `rue` varchar(100) NOT NULL,
  `cp` varchar(5) NOT NULL,
  `ville` varchar(30) NOT NULL,
  `pays` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`num`, `nom`, `prenom`, `pseudo`, `mdp`, `mail`, `rue`, `cp`, `ville`, `pays`) VALUES
(7, 'Sivas', 'Anolden', 'Agent', '1234', 'anolden@gmail.com', '49 RUE PAJOL', '75018', 'PARIS', 'France'),
(8, 'Sivas', 'Anolden', 'Agent', '1234', 'anolden@gmail.com', '49 RUE PAJOL', '75018', 'PARIS', 'Belgique'),
(21, 'ddd', 'd', 'd', 'dd', 'd', 'd', 'd', 'd', 'Belgique'),
(22, 'Ross', 'Mike', 'Mickeal', 'roos', 'mike@gmail.com', '49 main street', '96551', 'California', 'Allemagne'),
(23, 'Ross', 'Mike', 'Mickeal', 'roos', 'mike@gmail.com', '49 main street', '96551', 'California', 'Allemagne');

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE IF NOT EXISTS `produit` (
`numéro` int(100) NOT NULL,
  `designation` varchar(30) NOT NULL,
  `description` varchar(100) NOT NULL,
  `image` varchar(20) NOT NULL,
  `numCat` int(2) NOT NULL,
  `prix` double(10,2) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Contenu de la table `produit`
--

INSERT INTO `produit` (`numéro`, `designation`, `description`, `image`, `numCat`, `prix`) VALUES
(1, 'Salade ', 'Base, légume, fruit, protéine, garniture, sauce et taille au choix.', 'salade.jpg', 1, 3.50),
(2, 'Frites', 'Pomme de terre cuit par friture dans une graisse animale ou une huile végétale.', 'frites.jpg', 2, 3.00),
(3, 'Filet de saumon au four', 'Filet de saumon, huile d''olive, origan séché, sel, poivre au goût', 'saumon.jpg', 2, 8.50),
(4, 'Fish and chips', 'Poisson accompagné de frites', 'fishandchips.jpg', 2, 7.50),
(5, 'Samosa Chaat', 'Samosa ', 'samosa.jpg', 2, 4.00),
(6, 'Glace', 'Glace au Chocolat, à la Vanille, au Coco et à la Mangue', 'glaces.jpg', 4, 2.50),
(7, '7up', 'Canettes de 33cL', '7up.jpg', 3, 1.50),
(14, 'Tartes au pommes', 'Tarte faite à partir de pommes', 'tarte.jpg', 4, 2.50),
(15, 'Fondant au chocolat', 'Dessert au chocolat', 'fondant.jpg', 4, 3.50),
(16, 'Crème au caramel', 'Dessert au caramel', 'cremecaramel.jpg', 4, 3.00),
(17, 'Coca-Cola', 'Canettes de 33cL', 'COCA-COLA.jpg', 3, 1.50),
(18, 'Sprite', 'Canettes de 33cL', 'sprite.jpg', 3, 1.50),
(20, 'Orangina', 'Canettes de 33cL', 'Orangina.jpg', 3, 1.50),
(21, 'Pepsi', 'Canettes de 33cL', 'pepsi.jpg', 3, 1.50),
(22, 'Patlican Ezme', 'Dessert accompagné de persil', 'patlican.jpg', 4, 3.50),
(23, 'Grec kebab', 'Kebab turc fait maison accompagné de salade, tomate, oignon accompagné d''une sauce au choix', 'grec.jpg', 2, 6.50),
(24, 'Poulet grillé', 'Poulet fait maison accompagné de sauce et frites (facultatif)', 'poulet.jpg', 2, 8.50),
(25, 'Steak', 'Steak fait maison accompagné de frites (facultatif) et de sauce ketchup ou moyonnaise', 'steak.jpg', 2, 9.00),
(26, 'Houmous', 'Purée de pois chiche', 'houmous.jpg', 1, 2.00),
(27, 'Cacik', 'Soupe turque accompagné de persil ', 'cacik.jpg', 4, 4.50),
(28, 'Salade betterave', 'Salade accompagné de bettrave', 'saladebetterave.jpg', 1, NULL),
(29, 'Karisik Meze', 'Dessert accompagné de divers légumes', 'karisik.jpg', 4, 4.00),
(30, 'Aloo keema', 'Viande hachée de bœuf accompagné de pomme de terre ', 'aloo keema.jpg', 2, 7.50),
(31, 'Biryani', 'Le biryani, fait à base de riz préparé avec des épices de la viande des œufs ou des légumes', 'baryani.jpg', 2, 9.00),
(32, 'Nihari', 'Nihari est  composé de viande de jarret de bœuf ou d''agneau et de mouton', 'nihari.jpg', 2, 9.00),
(33, 'Kofta', 'Boulette de viande hachée', 'KOFTA-KASHMIR.jpg', 2, 8.00),
(34, 'Pizza margherita', 'Pizza fromages et sauce tomates', 'pizzamargherita.jpg', 2, 7.50),
(35, 'Salade mozzarella', 'Salade accompagnée de tomate et de mozarella', 'salademozza.jpg', 1, 3.00);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
 ADD PRIMARY KEY (`numCat`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
 ADD PRIMARY KEY (`num`);

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
 ADD PRIMARY KEY (`numéro`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
MODIFY `num` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT pour la table `produit`
--
ALTER TABLE `produit`
MODIFY `numéro` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
