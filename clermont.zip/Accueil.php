<?php
include('entete.php');
?>
<!doctype html>
<html lang="fr">
    <br><br><br><br>
    <body style="background-color:#E5E5E5;">
        <center>
            <h1>Bienvenue sur le site de la mairie de Clermont-Ferrand</h1>
            <h2>Voici la liste des lieux à visiter à Clermont-Ferrand<h2>
            <br>
        </center>
        <center>
        <table>
            <tr>
                <td>
                    <div class="card" style="width: 27rem;">
                        <img src="https://st3.depositphotos.com/1023345/12982/i/600/depositphotos_129822788-stock-photo-clermont-ferrand-cathedral.jpg" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Clermont-Ferrand</h5>
                            <p class="card-text">Cathédrale Notre-Dame-de-l'Assomption</p>
                            <a href="#" class="btn btn-primary stretched-link">Visiter</a>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 27rem;">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/68/Inauguration_vercingetorix_et_opera.JPG/1280px-Inauguration_vercingetorix_et_opera.JPG" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Clermont-Ferrand</h5>
                            <p class="card-text">Place de Jaude</p>
                            <a href="#" class="btn btn-primary stretched-link">Visiter</a>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 27rem;">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/c/cc/F08.N.-D._du_Port.0050.jpg" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Clermont-Ferrand</h5>
                            <p class="card-text">Basilique Notre-Dame du Port</p>
                            <a href="#" class="btn btn-primary stretched-link">Visiter</a>
                        </div>
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <div class="card" style="width: 27rem;">
                        <img src="https://www.clermontauvergnetourisme.com/wp-content/uploads/external/8804141-1600x900.jpg" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Jardin à Clermont-Ferrand</h5>
                            <p class="card-text">Jardin Lecoq</p>
                            <a href="#" class="btn btn-primary stretched-link">Visiter</a>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 27rem;">
                        <img src="https://img.lamontagne.fr/Y28ItYv7RXH-ntLVdCD9tpem8Pz41Xv5M2iGGTjZZ5Y/fit/657/438/sm/0/bG9jYWw6Ly8vMDAvMDAvMDYvMjMvOTYvMjAwMDAwNjIzOTYwOA.jpg" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Musée à Clermont-Ferrand</h5>
                            <p class="card-text">L'Aventure Michelin</p>
                            <a href="#" class="btn btn-primary stretched-link">Visiter</a>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 27rem;">
                        <img src="https://static.apidae-tourisme.com/filestore/objets-touristiques/images/7/65/8798471.jpg" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Stade nautique à Clermont-Ferrand</h5>
                            <p class="card-text">Stade Nautique Pierre-de-Coubertin</p>
                            <a href="#" class="btn btn-primary stretched-link">Visiter</a>
                        </div>
                    </div>
                </td>
            </tr>
        </table>
        </center>
    </body>
</html>