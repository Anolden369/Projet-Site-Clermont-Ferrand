<?php
include('entete.php');
?>
<!doctype html>
<html lang="fr">
    <br><br><br><br>
    <body style="background-color:#E5E5E5;">
        <center>
        <h1>Site de la mairie de Clermont-Ferrand</h1>
        <h2>Contactez-nous et venez visiter la mairie de Clermont-Ferrand !<h2>
        </center>
        <center>
            <table>
                <tr>
                    <td>
                        <div class="card" style="width: 25rem;">
                            <img src="https://media-cdn.tripadvisor.com/media/photo-s/0c/35/ed/ba/mairie-clermont-ferrand.jpg" class="card-img-top" alt="">
                            <div class="card-body">
                                <p class="card-title">Mairie de Clermont-Ferrand</p>
                                <h5 class="card-title">10 rue Philippe Marcombes - BP60</h5>
                                <h5 class="card-title">63033 Clermont Ferrand cedex 1</h5>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="card" style="width: 25rem;">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2782.555066775012!2d3.0849471946176705!3d45.780106431229136!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47f71be70fad6b33%3A0x7c97e41285ab5563!2sMairie%20de%20Clermont-Ferrand!5e0!3m2!1sfr!2sfr!4v1666712496880!5m2!1sfr!2sfr" width="400" height="340" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                            <div class="card-body">
                                <p class="card-title">Hôtel de Ville </p>
                                <h5 class="card-title">Tram : A - Arrêt Hôtel de Ville</h5>
                                <h5 class="card-title">Accueil de l'Hôtel de Ville ouvert du lundi au vendredi de 8h30 à 16h30.</h5>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="card" style="width: 25rem;">
                            <img src="https://media-cdn.tripadvisor.com/media/photo-s/1b/6f/41/93/mairie-de-clermont-ferrand.jpg" class="card-img-top" alt="">
                            <div class="card-body">
                                <h5 class="card-title">Téléphone : 04 73 42 63 63</h5>
                                <h5 class="card-title">Fax : 04 73 42 63 39</h5>
                                <h5 class="card-title">Numéro vert : 0800 300 029</h5>
                                <h5 class="card-title">Numéro vert médiation travaux : 0800 63 2003</h5>
                            </div>
                        </div>
                    </td>
                </tr>
            </table>
          </center>
    </body>
</html>