<!doctype html>
<?php
include('entete.php')
?>
<html lang="fr">
    <br><br><br><br>
    <body style="background-color:#E5E5E5;">
            <center>
                <h1>La Carte du Restaurant</h1>
                <h2>Les Plats de l'Etoilé L'Ostal<h2>
        <table>
            <tr>
                <td>
                    <div class="card" style="width: 12rem;">
                    <img src="image/Veloute-de-champignons-et-parmesan.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Velouté de champignons et parmesan</h5>
                        <p class="card-text">13.50€</p>
                        <a href="#" class="btn btn-primary stretched-link">Acheter</a>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 12rem;">
                    <img src="image/Paupiettes-de-dinde-aux-champignons.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                    <h5 class="card-title">Paupiettes de dinde aux champignons</h5>
                        <p class="card-text">12.00€</p>
                        <a href="#" class="btn btn-primary stretched-link">Acheter</a>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 16rem;">
                    <img src="image/burgers-au-reblochon.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Burgers au reblochon</h5>
                        <p class="card-text">23.50€</p>
                        <a href="#" class="btn btn-primary stretched-link">Acheter</a>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 15rem;">
                    <img src="image/osso-bucco-de-veau-aux-legumes.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Osso bucco de veau aux légumes</h5>
                        <p class="card-text">23.00€</p>
                        <a href="#" class="btn btn-primary stretched-link">Acheter</a>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 15rem;">
                    <img src="image/tarte-au-citron-meringuee.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Tarte au citron meringuée</h5>
                        <p class="card-text">13.50€</p>
                        <a href="#" class="btn btn-primary stretched-link">Acheter</a>
                    </div>
                    </div>
                </td>
                <td>
                    <div class="card" style="width: 15rem;">
                    <img src="image/fondant-chocolat-coeur-coulant.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Fondant chocolat cœur coulant</h5>
                        <p class="card-text">14.50</p>
                        <a href="#" class="btn btn-primary stretched-link">Acheter</a>
                    </div>
                    </div>
                </td>
            </tr>
        </table>
    </body>
</html>